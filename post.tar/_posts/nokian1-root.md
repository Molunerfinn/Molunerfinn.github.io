title: 诺基亚N1国行版已经被ROOT！
tags:
  - NokiaN1
id: 118
categories:
  - 其他
  - 极客
date: 2015-05-23 01:08:45
---

已经率先尝试，发现果然ROOT成功，首先感谢一下为此做出贡献的网友！
![](http://bbs.byr.cn/att/DigiLife/0/281953/527)
<!--more-->

![](http://bbs.byr.cn/att/DigiLife/0/281953/2050359\&quot;)
![](http://bbs.byr.cn/att/DigiLife/0/281953/4152107\&quot;)