title: 网站更新日志-6
tags:
  - 更新日志
id: 266
categories:
  - WordPress日常
  - 日志
date: 2015-06-20 23:21:40
---

##说在前头
这个主题原本是Moyu的[EverBox](http://demo.20theme.com/everbox-cn/ "http://demo.20theme.com/everbox-cn/")，后来经过修改，二次开发后我将其命名为Mofinn，并会一直更新。
Mofinn的Github地址在[这里](https://github.com/Molunerfinn/Mofinn "https://github.com/Molunerfinn/Mofinn")
目前已经更新至v1.0PROA7

* * *

> 6.20更新日志

PS：最近比较忙，本来打算A7版本更新的时候不止是加入分享代码。不过最近事情多暂时先这样。

##更新日志
文章页添加了百度分享代码。重新设定了主题一下使得文章列表的文章标题上能显示分类标签。

###更新效果
- 在文章页左侧能看到一个分享的按钮。分享列表已经经过筛选。
- 文章列表页的文章标题上现在能显示出分类标签了。之前显示不出来是设定出了问题。

###不足以及有待改进之处

手机端的导航菜单经过分析已经暂时放弃更改。自从能显示出分类标签后，手机端具体分类目前可以靠标签来查看。PROA系列的更新将会止步于网站首页的完成。因为目前首页只是拿了WODRPRESS的一个页面来充当的。