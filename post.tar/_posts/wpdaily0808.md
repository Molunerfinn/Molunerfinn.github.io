title: 网站更新日志-7
tags:
  - 更新日志
id: 295
categories:
  - WordPress日常
  - 日志
date: 2015-08-08 00:58:56
---

## 说在前头
这个主题原本是Moyu的[EverBox](http://demo.20theme.com/everbox-cn/ "http://demo.20theme.com/everbox-cn/")，后来经过修改，二次开发后我将其命名为Mofinn，并会一直更新。
Mofinn的Github地址在[这里](https://github.com/Molunerfinn/Mofinn "https://github.com/Molunerfinn/Mofinn")
目前已经更新至v1.0PROA8
<!--more-->
* * *

> 8.08更新日志

加入首页，v1.0PROA系列更新结束。接下去的更新是PROB系列的更新。

## 更新日志
首页加入。

#### 更新效果
现在进入molunerfinn.com后会默认出现首页了。不再是之前的那种用一个WordPress页面来充当的首页了。

#### 不足以及有待改进之处
首页说实话并不是很满意。不过大体的风格就是简约明了，这次还用上了Bootstrap。今后应该会加入图片轮播等效果。接下去PROB的更新就将会聚焦在全站AJAX的问题上了，主要实现目标是能够做出一个全站播放音乐的播放器，不随查看文章更改而重新播放。效果类似于QQ空间的音乐播放器。
