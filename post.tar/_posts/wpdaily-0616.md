title: 网站更新日志-4
tags:
  - 更新日志
id: 250
categories:
  - WordPress日常
  - 日志
date: 2015-06-16 03:02:31
---

##说在前头
这个主题原本是Moyu的[EverBox](http://demo.20theme.com/everbox-cn/ "http://demo.20theme.com/everbox-cn/")，后来经过修改，二次开发后我将其命名为Mofinn，并会一直更新。
Mofinn的Github地址在[这里](https://github.com/Molunerfinn/Mofinn "https://github.com/Molunerfinn/Mofinn")
目前已经更新至v1.0PROA5

* * *

> 6.16更新日志

##更新说明
更新了文章列表文章标题显示的一个特效。提高交互性。

####更新效果
- 鼠标接近文章标题的时候能够触发特效，能够看到标题缓慢滑出以及标题颜色变色的效果。

####不足以及有待改进之处
手机端的导航菜单栏的问题还没有解决。目前发现结构还有点复杂，所以先更新了文章标题的显示效果。在Mofinn的PROA系列中是一定会将手机端导航菜单栏问题解决的。